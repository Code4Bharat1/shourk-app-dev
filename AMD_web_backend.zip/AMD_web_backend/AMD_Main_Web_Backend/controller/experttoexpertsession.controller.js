import { ExpertToExpertSession } from "../model/experttoexpertsession.model.js";
import mongoose from "mongoose";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import asyncHandler from "../utils/asyncHandler.js";
import ApiError from "../utils/ApiError.js";
import { createZoomMeeting } from "../utils/createZoomMeeting.js";
import { UserToExpertSession } from "../model/usertoexpertsession.model.js";
import axios from "axios"; // Make sure to import axios
import { generateVideoSDKSignature } from "../utils/videoSDKHelper.js"; // Assuming you have a utility to generate meeting numbers
import { User } from "../model/user.model.js";
import Rating from "../model/rating.model.js"; // Import Rating model
import { Expert } from "../model/expert.model.js"; // Added Expert model import
import { applyGiftCardToBooking } from "./giftcard.controller.js"; // Import gift card function
import { sendEmail } from "../utils/emailService.js"; // Import sendEmail utility
import { Transaction } from "../model/transaction.model.js";

dotenv.config();

// Helper function to check if the consulting expert's session time is available
const checkAvailability = async (
  consultingExpertID,
  sessionDate,
  sessionTime
) => {
  try {
    // Find if there is any session already booked for the consulting expert at the same sessionTime and sessionDate
    const existingExpertSession = await ExpertToExpertSession.findOne({
      consultingExpertID: consultingExpertID,
      sessionDate,
      sessionTime,
    });

    // If expert-to-expert session exists, time is not available
    if (existingExpertSession) {
      return false;
    }

    // Now check if there's a user-to-expert session booked
    const existingUserSession = await UserToExpertSession.findOne({
      expertId: consultingExpertID,
      sessionDate,
      sessionTime,
    });

    // If no session is found in either collection, the time is available
    return !existingUserSession;
  } catch (error) {
    throw new ApiError("Error checking availability", 500);
  }
};

// Function to create a TAP payment (This will be used for WALLET TOP-UP, not direct session payment)
const createTapPayment = async (
  sessionData,
  price,
  successRedirectUrl,
  cancelRedirectUrl
) => {
  try {
    // Convert price to halalas (smallest currency unit for SAR)
    const amountInHalalas = Math.round(parseFloat(price) * 100);

    if (isNaN(amountInHalalas) || amountInHalalas <= 0) {
      throw new Error("Invalid price amount. Price must be a positive number.");
    }

    const payload = {
      amount: amountInHalalas, // Use the converted amount
      currency: "SAR", // Change to your currency
      customer: {
        first_name: sessionData.firstName,
        last_name: sessionData.lastName,
        email: sessionData.email,
        phone: {
          country_code: "+971", // Default to UAE, adjust as needed
          number: sessionData.mobile,
        },
      },
      source: { id: "src_all" },
      redirect: {
        url: successRedirectUrl,
      },
      post: {
        url: cancelRedirectUrl,
      },
      metadata: {
        sessionId: sessionData._id.toString(),
        sessionType: "expert-to-expert",
      },
    };

    const response = await axios.post(
      "https://api.tap.company/v2/charges",
      payload,
      {
        headers: {
          Authorization: `Bearer ${process.env.TAP_SECRET_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data;
  } catch (error) {
    console.error("Error creating TAP payment:", error.response?.data || error);
    throw new Error(
      "Payment gateway error: " +
        (error.response?.data?.message || error.message)
    );
  }
};

// Get expert booked slots from both ExpertToExpertSession and UserToExpertSession collections
const getExpertBookedSlots = asyncHandler(async (req, res) => {
  const { expertId } = req.params;

  try {
    // Find booked slots in ExpertToExpertSession
    const expertToExpertSessions = await ExpertToExpertSession.find({
      consultingExpertID: expertId,
      status: {
        $in: [
          "pending",
          "confirmed",
          "unconfirmed",
          "completed",
          "Rating Submitted",
        ],
      },
    });

    // Find booked slots in UserToExpertSession
    const userToExpertSessions = await UserToExpertSession.find({
      expertId: expertId,
      status: {
        $in: [
          "pending",
          "confirmed",
          "unconfirmed",
          "completed",
          "Rating Submitted",
        ],
      },
    });

    // Extract slots from expert-to-expert sessions
    const expertToExpertSlots = expertToExpertSessions.flatMap(
      (session) => session.slots
    );

    // Extract slots from user-to-expert sessions
    const userToExpertSlots = userToExpertSessions.flatMap(
      (session) => session.slots
    );

    // Combine slots from both collections
    const allBookedSlots = [...expertToExpertSlots, ...userToExpertSlots];

    res.status(200).json({
      success: true,
      data: allBookedSlots,
    });
  } catch (error) {
    console.error("Error fetching booked slots:", error);
    res.status(500).json({
      success: false,
      message: "Error fetching booked slots",
      error: error.message,
    });
  }
});

// Controller for "My Bookings" - When the logged-in expert is the one who booked the session
const getMyBookings = asyncHandler(async (req, res) => {
  const token = req.header("Authorization")?.replace("Bearer ", "");

  if (!token) {
    return res.status(400).json({ message: "Token is required" });
  }

  try {
    const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
    const expertId = decoded._id;

    // Find sessions where the logged-in expert is the one who booked the session
    const sessions = await ExpertToExpertSession.find({
      expertId: expertId,
    })
      .populate("expertId", "firstName lastName")
      .populate("consultingExpertID", "firstName lastName")
      .sort({ sessionDate: 1 });

    if (!sessions.length) {
      return res
        .status(404)
        .json({ message: "No bookings found for this expert." });
    }

    res.status(200).json(sessions);
  } catch (error) {
    console.error("Error fetching bookings:", error);
    res.status(500).json({
      message: "An error occurred while fetching bookings.",
      error: error.message,
    });
  }
});

const getMySessions = asyncHandler(async (req, res) => {
  const token = req.header("Authorization")?.replace("Bearer ", "");

  if (!token) {
    return res.status(400).json({ message: "Token is required" });
  }

  try {
    const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
    const expertId = decoded._id;

    // Find sessions where the logged-in expert is the consulting expert
    const expertSessions = await ExpertToExpertSession.find({
      consultingExpertID: expertId,
    })
      .populate("expertId", "firstName lastName email")
      .populate("consultingExpertID", "firstName lastName email")
      .select('+zoomMeetingLink +zoomMeetingId +zoomPassword +zoomSessionName') // Explicitly select these fields
      .sort({ expertSessionDate: 1 });

    // Find sessions where the logged-in expert is the consulting expert
    const userSessions = await UserToExpertSession.find({
      expertId: expertId,
    })
      .populate("userId", "firstName lastName email")
      .populate("expertId", "firstName lastName email")
      .select('+zoomMeetingLink +zoomMeetingId +zoomPassword +zoomSessionName') // Explicitly select these fields
      .sort({ createdAt: -1 });

    // Check if both expertSessions and userSessions are empty
    if (expertSessions.length === 0 && userSessions.length === 0) {
      return res
        .status(404)
        .json({ message: "No sessions found for this expert." });
    }

    // Format expertSessions to always include consultingExpertID and expertId as strings
    const formattedExpertSessions = expertSessions.map(session => session.toObject());
const formattedUserSessions = userSessions.map(session => session.toObject());


    // Respond with the sessions
    res.status(200).json({ 
      success: true,
      expertSessions: formattedExpertSessions, 
      userSessions: formattedUserSessions
    });
  } catch (error) {
    console.error("Error fetching sessions:", error);
    res.status(500).json({
      success: false,
      message: "An error occurred while fetching sessions.",
      error: error.message,
    });
  }
});

// Expert-to-Expert session booking controller
const bookExpertToExpertSession = asyncHandler(async (req, res) => {
  const {
    consultingExpertID,
    areaOfExpertise,
    slots,
    duration,
    note,
    firstName,
    lastName,
    email,
    mobile,
    price, // From frontend
    redemptionCode, // Optional
  } = req.body;

  console.log("🔍 Received booking:", req.body);


  const token = req.header("Authorization")?.replace("Bearer ", "");
  if (!token) throw new ApiError(400, "Token is required");

  const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
  const bookingExpertId = decoded._id;

  if (bookingExpertId === consultingExpertID) {
    throw new ApiError(400, "An expert cannot book a session with themselves.");
  }

  const parsedPrice = parseFloat(price);
  if (isNaN(parsedPrice) || parsedPrice < 0) {
    throw new ApiError(400, "Invalid price. Must be a non-negative number.");
  }

  let finalPriceToPay = parsedPrice;
  let giftCardDetails = null;
  let paymentMethodForSession = parsedPrice === 0 ? "free" : "wallet";
  let paymentStatusForSession = "pending";

  // 1️⃣ Handle Gift Card (if applicable)
  if (parsedPrice > 0 && redemptionCode) {
    try {
      const giftCardResult = await applyGiftCardToBooking(
        redemptionCode,
        parsedPrice
      );
      finalPriceToPay = parsedPrice - giftCardResult.redeemedAmount;
      if (finalPriceToPay < 0) finalPriceToPay = 0;

      giftCardDetails = {
        giftCardId: giftCardResult.giftCardId,
        amountRedeemed: giftCardResult.redeemedAmount,
        codeUsed: redemptionCode,
      };

      paymentMethodForSession =
        finalPriceToPay <= 0 ? "gift_card" : "gift_card_plus_wallet";
      console.log(
        `Gift card ${redemptionCode} applied. Original: ${parsedPrice}, Redeemed: ${giftCardResult.redeemedAmount}, Due: ${finalPriceToPay}`
      );
    } catch (gcError) {
      console.error("Gift card redemption error:", gcError.message);
      throw new ApiError(400, `Gift card error: ${gcError.message}`);
    }
  }

  // 2️⃣ Determine payment status
  if (parsedPrice === 0 || finalPriceToPay === 0) {
    paymentStatusForSession = "completed";
    paymentMethodForSession = parsedPrice === 0 ? "free" : "gift_card";
  } else {
    // Session needs payment via wallet (handled by payAnotherExpert after booking)
    paymentStatusForSession = "pending";
  }

  // 3️⃣ Prepare session data
  const sessionData = {
    expertId: bookingExpertId,
    consultingExpertID: consultingExpertID,
    areaOfExpertise,
    slots,
    status: "unconfirmed",
    sessionType: "expert-to-expert",
    duration,
    note,
    firstName,
    lastName,
    mobile,
    email,
    price: parsedPrice,
    paymentMethod: paymentMethodForSession,
    paymentStatus: paymentStatusForSession,
    paymentAmount: finalPriceToPay, // Show amount due for transparency
    giftCardRedeemedId: giftCardDetails ? giftCardDetails.giftCardId : null,
    giftCardAmountRedeemed: giftCardDetails ? giftCardDetails.amountRedeemed : 0,
  };

  // 4️⃣ Create session
  const newSession = new ExpertToExpertSession(sessionData);
  await newSession.save();

  // 5️⃣ Send Email Notifications
  const consultingExpert = await Expert.findById(consultingExpertID);
  try {
    // Notify booking expert
    await sendEmail({
      to: email,
      subject: "Session Booking Confirmation - Expert to Expert",
      html: `
        <h1>Booking Confirmed!</h1>
        <p>Hello ${firstName},</p>
        <p>Your expert-to-expert session with ${consultingExpert?.firstName || ''} ${consultingExpert?.lastName || ''} is booked and is awaiting confirmation from the consulting expert.</p>
        <p>Session ID: ${newSession._id}</p>
        <p>Status: ${newSession.status}</p>
        <p>Amount Due: ${finalPriceToPay} SAR</p>
        ${giftCardDetails ? `<p>Gift Card Redeemed: ${giftCardDetails.amountRedeemed} SAR</p>` : ''}
        <p>Thank you for using our platform.</p>
      `
    });
    console.log(`Confirmation email sent to booking expert: ${email}`);

    // Notify consulting expert
    if (consultingExpert?.email) {
      await sendEmail({
        to: consultingExpert.email,
        subject: "New Expert Session Request",
        html: `
          <h1>New Session Request</h1>
          <p>Hello ${consultingExpert.firstName},</p>
          <p>You have a new expert-to-expert session request from ${firstName} ${lastName}.</p>
          <p>Please log in to accept or decline.</p>
          <p>Session ID: ${newSession._id}</p>
          <p>Area of Expertise: ${areaOfExpertise}</p>
          <p>Duration: ${duration}</p>
          ${note ? `<p>Note: ${note}</p>` : ''}
        `
      });
      console.log(`Notification email sent to consulting expert: ${consultingExpert.email}`);
    }
  } catch (emailError) {
    console.error("Email sending error for E2E session:", emailError);
  }

  const sessionObj = newSession.toObject();
  sessionObj.consultingExpertID = consultingExpertID;
  sessionObj.expertId = bookingExpertId;

  return res.status(201).json({
    message: `Session booked successfully. Status: ${newSession.status}, Payment Status: ${newSession.paymentStatus}.`,
    session: sessionObj,
  });
});


// Payment webhook handler - This was originally for TAP session payments.
// It might be repurposed or a new one created if TAP is used for WALLET TOP-UPs
// and needs to update a transaction record related to wallet top-up.
// For gift card purchases, there's a separate webhook in giftcard.controller.
// ... (handlePaymentWebhook function - can be kept for reference or if wallet top-up uses a similar mechanism)

// Payment success handler - API endpoint for success redirect
// Also originally for TAP session payments.
// ... (handlePaymentSuccess function - can be kept for reference)

// Update your acceptSession function in expert controller to include user meeting link

// Generate a unique meeting number for Zoom Video SDK
const generateMeetingNumber = () => {
  return Math.floor(Math.random() * 9000000000) + 1000000000; // 10-digit number
};

// Generate a consistent session password for the meeting
const generateZoomPassword = () => {
  const chars = "0123456789abcdefghijklmnopqrstuvwxyz";
  let password = "";
  for (let i = 0; i < 8; i++) {
    password += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return password; // Always exactly 8 characters
};

const acceptSession = asyncHandler(async (req, res) => {
  const { id, selectedDate, selectedTime } = req.body;

  try {
      let session = await ExpertToExpertSession.findById(id)
          .populate("expertId", "firstName lastName email")
          .populate("consultingExpertID", "firstName lastName email");

      if (!session) {
          session = await UserToExpertSession.findById(id)
              .populate("userId", "firstName lastName email")
              .populate("expertId", "firstName lastName email");
      }

      if (!session) {
          return res.status(404).json({ message: "Session not found" });
      }

      // Check if payment is completed
      if (session.collection.name === "experttoexpertsessions") {
          const isValidPayment =
              session.paymentStatus === "completed" ||
              session.paymentStatus === "not_applicable" ||
              (session.paymentMethod === "gift_card" && session.giftCardAmountRedeemed > 0) ||
              (session.paymentMethod === "gift_card_plus_wallet" && session.paymentAmount > 0);

          if (!isValidPayment) {
              console.log("Payment verification failed:", {
                  sessionId: session._id,
                  paymentStatus: session.paymentStatus,
                  paymentMethod: session.paymentMethod,
                  giftCardAmount: session.giftCardAmountRedeemed,
                  walletAmount: session.paymentAmount
              });
              return res.status(400).json({
                  message: "Cannot accept session with incomplete payment",
                  details: {
                      paymentStatus: session.paymentStatus,
                      paymentMethod: session.paymentMethod
                  }
              });
          }
      }

      // Update slots and status
      session.slots = [{
          selectedDate: selectedDate,
          selectedTime: selectedTime,
      }];
      session.status = "confirmed";

      // Generate Zoom meeting details
      const meetingNumber = generateMeetingNumber();
      const zoomPassword = generateZoomPassword();
      session.zoomMeetingId = meetingNumber.toString();
      session.zoomSessionName = `session_${session._id}_${meetingNumber}`;
      session.zoomPassword = zoomPassword;

      session.zoomMeetingLink = `/expertpanel/sessioncall?meetingId=${meetingNumber}&sessionId=${session._id}`;
      session.userMeetingLink = session.collection.name === "usertoexpertsessions"
          ? `/userpanel/sessioncall?meetingId=${meetingNumber}&sessionId=${session._id}`
          : `/expertpanel/sessioncall?meetingId=${meetingNumber}&sessionId=${session._id}`;

      await session.save();

      // ✅ Process payout upon confirmation
      
        if (
          !session.payoutProcessed &&
          session.paymentStatus === 'completed' &&
          session.price > 0 &&
          session.collection.name === "experttoexpertsessions"
      ) {
          const expertToPayId = session.consultingExpertID?._id || session.consultingExpertID;
          const expertDoc = await Expert.findById(expertToPayId);
          if (expertDoc) {
              const averageRating = expertDoc.averageRating || 0;
              const expertSharePercentage = averageRating >= 4 ? 0.7 : 0.5;
              const expertShare = session.price * expertSharePercentage;
              const platformFee = session.price - expertShare;
      
              const pendingCreditTx = await Transaction.findOne({
                expertId: expertToPayId,
                type: 'DEPOSIT',
                'metadata.sessionId': session._id.toString(), // ✅ Ensure string match
                status: 'PENDING'
            });
            
      
              if (pendingCreditTx) {
                  // ✅ Credit expert's wallet with expertShare
                  expertDoc.wallets.earning.balance += expertShare;
                  expertDoc.wallets.earning.ledger.push(pendingCreditTx._id);
      
                  // ✅ Update transaction amount and status
                  pendingCreditTx.amount = expertShare; // ensure consistency
                  pendingCreditTx.status = 'COMPLETED';
                  pendingCreditTx.description = 'Expert-to-Expert session earnings (confirmed)';
                  pendingCreditTx.metadata.payoutConfirmedAt = new Date();
                  await pendingCreditTx.save();
      
                  expertDoc.transactions = expertDoc.transactions || [];
                  if (!expertDoc.transactions.includes(pendingCreditTx._id)) {
                      expertDoc.transactions.push(pendingCreditTx._id);
                  }
      
                  await expertDoc.save();
      
                  session.expertPayoutAmount = expertShare;
                  session.platformFeeAmount = platformFee;
                  session.payoutProcessed = true;
                  await session.save();
      
                  console.log(`[acceptSession] Payout of ${expertShare} SAR credited to consulting expert ${expertToPayId} for session ${session._id}. Transaction updated and marked COMPLETED.`);
              } else {
                  console.warn(`[acceptSession] No pending credit transaction found for session ${session._id}. Cannot process payout.`);
              }
          } else {
              console.warn(`[acceptSession] Consulting expert ${expertToPayId} not found while processing payout for session ${session._id}.`);
          }
      }
      

      // ✅ Send confirmation email
      try {
          let recipientEmail, recipientFirstName, recipientLastName;
          let expertFirstName = session.collection.name === "usertoexpertsessions"
              ? session.expertId.firstName
              : session.consultingExpertID.firstName;
          let expertLastName = session.collection.name === "usertoexpertsessions"
              ? session.expertId.lastName
              : session.consultingExpertID.lastName;

          if (session.collection.name === "usertoexpertsessions") {
              recipientEmail = session.userId.email;
              recipientFirstName = session.userId.firstName;
              recipientLastName = session.userId.lastName;
          } else {
              recipientEmail = session.expertId.email;
              recipientFirstName = session.expertId.firstName;
              recipientLastName = session.expertId.lastName;
          }

          if (recipientEmail) {
              console.log(`Sending confirmation email to: ${recipientEmail}`);
              await sendEmail({
                  to: recipientEmail,
                  subject: "Session Confirmed!",
                  html: `
                      <h1>Your Session is Confirmed!</h1>
                      <p>Hello ${recipientFirstName},</p>
                      <p>Your session with expert ${expertFirstName} ${expertLastName} has been confirmed.</p>
                      <p>Session ID: ${session._id}</p>
                      <p>You can join your session here: <a href="${process.env.FRONTEND_URL}${session.userMeetingLink}">${process.env.FRONTEND_URL}${session.userMeetingLink}</a></p>
                      <p>Please be ready a few minutes before your session starts.</p>
                      <p>Thank you for using our platform.</p>
                  `
              });
              console.log(`Confirmation email sent to ${recipientEmail} for session ${session._id}`);
          } else {
              console.warn(`Recipient email not found for session ${session._id}. Confirmation email not sent.`);
          }
      } catch (emailError) {
          console.error(`Error sending confirmation email for session ${session._id}:`, emailError);
      }

      const sessionObj = session.toObject();
      sessionObj.consultingExpertID = session.consultingExpertID?._id?.toString?.() || session.consultingExpertID?.toString?.() || session.consultingExpertID || "";
      sessionObj.expertId = session.expertId?._id?.toString?.() || session.expertId?.toString?.() || session.expertId || "";

      res.status(200).json({
          success: true,
          message: "Session accepted and payout processed (if applicable).",
          session: sessionObj
      });
  } catch (error) {
      console.error("Error in acceptSession:", error);
      res.status(500).json({
          success: false,
          message: "Error accepting session",
          error: error.message
      });
  }
});


// New endpoint to generate Video SDK signature when joining
const generateVideoSDKAuth = asyncHandler(async (req, res) => {
  const { meetingNumber, role = 0 } = req.body;

  try {
    const authData = generateVideoSDKSignature(meetingNumber, role);

    // Secure logging - only log non-sensitive information
    console.log('=== GENERATE VIDEO SDK TOKEN ===');
    console.log(`Meeting ID: ${meetingNumber}`);
    console.log('✅ Generated token successfully');

    res.status(200).json({
      success: true,
      ...authData,
    });
  } catch (error) {
    console.error("Error generating Video SDK signature:", error);
    res.status(500).json({
      message: "Failed to generate Video SDK authentication",
      error: error.message,
    });
  }
});

// Complete session endpoint - updates status to "completed"
const completeSession = asyncHandler(async (req, res) => {
  const { sessionId, endTime, status = "completed", actualDuration } = req.body;

  try {
    console.log("Completing session:", {
      sessionId,
      endTime,
      status,
      actualDuration,
    });

    // Try to find the session in ExpertToExpertSession first
    let session = await ExpertToExpertSession.findById(sessionId);
    let sessionType = "expert-to-expert";

    // If not found, try UserToExpertSession
    if (!session) {
      session = await UserToExpertSession.findById(sessionId);
      sessionType = "user-to-expert";
    }

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session not found",
      });
    }

    // Update session with completion details
    const updateData = {
      status: status,
      endTime: new Date(endTime),
      completedAt: new Date(),
      actualDuration: actualDuration || session.duration,
    };

    // Update the session
    const updatedSession =
      sessionType === "expert-to-expert"
        ? await ExpertToExpertSession.findByIdAndUpdate(sessionId, updateData, {
            new: true,
          })
        : await UserToExpertSession.findByIdAndUpdate(sessionId, updateData, {
            new: true,
          });

    console.log("Session updated successfully:", {
      sessionId,
      sessionType,
      status: updatedSession.status,
      endTime: updatedSession.endTime,
    });

    res.status(200).json({
      success: true,
      message: "Session completed successfully",
      session: updatedSession,
      sessionType: sessionType,
    });
  } catch (error) {
    console.error("Error completing session:", error);
    res.status(500).json({
      success: false,
      message: "Failed to complete session",
      error: error.message,
    });
  }
});

// Alternative endpoint format (PUT /session/:id/complete)
const completeSessionById = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { status = "completed", endTime, actualDuration } = req.body;

  try {
    console.log("Completing session by ID:", {
      id,
      status,
      endTime,
      actualDuration,
    });

    // Try both session types
    let session = await ExpertToExpertSession.findById(id);
    let sessionType = "expert-to-expert";

    if (!session) {
      session = await UserToExpertSession.findById(id);
      sessionType = "user-to-expert";
    }

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session not found",
      });
    }

    // Update session
    const updateData = {
      status: status,
      endTime: new Date(endTime || new Date()),
      completedAt: new Date(),
      actualDuration: actualDuration || session.duration,
    };

    const updatedSession =
      sessionType === "expert-to-expert"
        ? await ExpertToExpertSession.findByIdAndUpdate(id, updateData, {
            new: true,
          })
        : await UserToExpertSession.findByIdAndUpdate(id, updateData, {
            new: true,
          });

    res.status(200).json({
      success: true,
      message: "Session completed successfully",
      session: updatedSession,
      sessionType: sessionType,
    });
  } catch (error) {
    console.error("Error completing session by ID:", error);
    res.status(500).json({
      success: false,
      message: "Failed to complete session",
      error: error.message,
    });
  }
});

// Get session details endpoint (if not already exists)
const getSessionDetails = asyncHandler(async (req, res) => {
  const { sessionId } = req.params;

  try {
    // Try to find in both collections
    let session = await ExpertToExpertSession.findById(sessionId)
      .populate("expertId", "firstName lastName email")
      .populate("consultingExpertID", "firstName lastName email");

    let sessionType = "expert-to-expert";

    if (!session) {
      session = await UserToExpertSession.findById(sessionId)
        .populate("userId", "firstName lastName email")
        .populate("expertId", "firstName lastName email");
      sessionType = "user-to-expert";
    }

    if (!session) {
      return res.status(404).json({
        success: false,
        message: "Session not found",
      });
    }

    // Convert session to plain object and ensure IDs are included as strings
    const sessionObj = session.toObject ? session.toObject() : { ...session };
    
    // Always include these fields as strings
    sessionObj.consultingExpertID = (
      session.consultingExpertID?._id?.toString?.() ||
      session.consultingExpertID?.toString?.() ||
      session.consultingExpertID ||
      (sessionObj.consultingExpertID?._id?.toString?.() || sessionObj.consultingExpertID?.toString?.() || sessionObj.consultingExpertID) ||
      ""
    );
    
    sessionObj.expertId = (
      session.expertId?._id?.toString?.() ||
      session.expertId?.toString?.() ||
      session.expertId ||
      (sessionObj.expertId?._id?.toString?.() || sessionObj.expertId?.toString?.() || sessionObj.expertId) ||
      ""
    );
    
    if (sessionObj.userId) {
      sessionObj.userId = sessionObj.userId?._id?.toString?.() || sessionObj.userId?.toString?.() || sessionObj.userId;
    }

    // Debug log to verify outgoing response
    console.log('Sending session details:', sessionObj);

    res.status(200).json({
      success: true,
      session: sessionObj,
      sessionType: sessionType,
      duration: session.duration // Ensure duration is at the top level
    });
  } catch (error) {
    console.error("Error fetching session details:", error);
    res.status(500).json({
      success: false,
      message: "Failed to fetch session details",
      error: error.message,
    });
  }
});

// // Helper: Convert "Quick - 15min" → 15
// const getDurationInMinutes = (durationStr) => {
//   if (typeof durationStr === "number") return durationStr;
//   const match = durationStr.match(/(\d+)/);
//   return match ? parseInt(match[1], 10) : 15;
// };

// To decline the user request
const declineSession = asyncHandler(async (req, res) => {
  const { id } = req.body; // Session ID
  const decliningExpertId = req.user?._id; // Expert initiating the decline

  if (!decliningExpertId) {
    throw new ApiError(401, "Expert not authenticated.");
  }

  let session = await ExpertToExpertSession.findById(id);
  let sessionType = "expert-to-expert";
  let bookerId; // To know whose wallet to refund

  if (session) {
    // Ensure the declining expert is the consultingExpertID for E2E sessions
    if (
      session.consultingExpertID.toString() !== decliningExpertId.toString()
    ) {
      throw new ApiError(
        403,
        "Forbidden: You are not the consulting expert for this E2E session."
      );
    }
    bookerId = session.expertId; // The expert who booked the session
  } else {
    session = await UserToExpertSession.findById(id);
    sessionType = "user-to-expert";
    if (session) {
      // Ensure the declining expert is the expertId for U2E sessions
      if (session.expertId.toString() !== decliningExpertId.toString()) {
        throw new ApiError(
          403,
          "Forbidden: You are not the expert for this U2E session."
        );
      }
      bookerId = session.userId; // The user who booked the session
    } else {
      throw new ApiError(404, "Session not found.");
    }
  }

  if (session.status === "rejected") {
    return res.status(400).json({ message: "Session already rejected." });
  }

  const oldStatus = session.status;
  session.status = "rejected";

  // Refund logic for wallet payments (Option B: Gift cards not refunded to card)
  if (
    session.paymentStatus === "completed" &&
    session.paymentAmount > 0 &&
    bookerId
  ) {
    // paymentAmount stores the amount paid from wallet after gift card (if any)
    const booker = await Expert.findById(bookerId); // Booker is always a User (even if an expert booking another expert)
    if (booker) {
      booker.wallets.earning.balance =
        (booker.wallets.earning.balance || 0) + session.paymentAmount;
      await booker.save();
      session.paymentStatus = "refunded_to_wallet"; // New status to indicate wallet refund
      console.log(
        `Refunded ${session.paymentAmount} to user ${bookerId} wallet for declined session ${session._id}. New balance: ${booker.wallets.earning.balance}`
      );
      // TODO: Add a transaction record for this refund
    } else {
      console.error(
        `Booker with ID ${bookerId} not found for wallet refund on session ${session._id}.`
      );
      // Decide how to handle this: proceed with rejection but log, or throw error?
      // For now, we'll proceed with rejection and log the refund issue.
      session.paymentStatus = "refund_failed_booker_not_found";
    }
  } else if (
    session.paymentStatus === "completed" &&
    session.giftCardAmountRedeemed > 0 &&
    session.paymentAmount === 0
  ) {
    // Paid fully by gift card, no wallet refund as per Option B.
    // Mark payment as 'gift_card_not_refunded' or similar if you need to track this state.
    session.paymentStatus = "declined_gift_card_payment";
  }

  await session.save();

  // TODO: Send email notification to the booker about the session rejection and refund (if any).

  res.status(200).json({
    message: "Session rejected successfully.",
    session,
  });
});

const submitRatingAndProcessPayout = asyncHandler(async (req, res) => {
  const { sessionId } = req.params;
  const { rating, comment } = req.body;
  const raterMongoId = req.user?._id;

  console.log(
    `[Rating Submission] Received for session ${sessionId}: Rating - ${rating}, Comment - '${comment}', RaterID - ${raterMongoId}`
  );

  if (!rating || rating < 1 || rating > 5) {
    return res
      .status(400)
      .json({ message: "Invalid rating. Must be between 1 and 5." });
  }

  if (!raterMongoId) {
    return res.status(401).json({ message: "User not authenticated." });
  }

  try {
    let session = await ExpertToExpertSession.findById(sessionId);
    let sessionType = "expert-to-expert";
    let ratedExpertId;
    let raterType;

    if (!session) {
      session = await UserToExpertSession.findById(sessionId);
      sessionType = "user-to-expert";
    }

    if (!session) {
      return res.status(404).json({ message: "Session not found." });
    }

    // Authorization & Determine ratedExpertId and raterType
    if (sessionType === "expert-to-expert") {
      if (session.expertId.toString() !== raterMongoId.toString()) {
        return res
          .status(403)
          .json({
            message:
              "Forbidden: You did not book this expert-to-expert session.",
          });
      }
      ratedExpertId = session.consultingExpertID;
      raterType = "Expert"; // The expert who booked is rating the consulting expert
    } else {
      // user-to-expert
      if (session.userId.toString() !== raterMongoId.toString()) {
        return res
          .status(403)
          .json({
            message:
              "Forbidden: You did not participate in this user-to-expert session.",
          });
      }
      ratedExpertId = session.expertId;
      raterType = "User"; // The user is rating the expert
    }

    if (session.status !== "completed") {
      return res
        .status(400)
        .json({
          message: "Session must be 'completed' before submitting a rating.",
        });
    }

    // Check if a Rating document already exists for this specific context in the ratings collection
    const existingRatingDoc = await Rating.findOne({
      expertId: ratedExpertId,
      raterId: raterMongoId,
      sessionType: sessionType,
      // If you add sessionId to Rating model in future, you'd query by that too for more specificity
    });

    // Check if payout has already been processed for this session
    if (session.payoutProcessed) {
      return res.status(400).json({
        message: "Payout has already been processed for this session.",
        details:
          "Rating cannot be submitted or changed after payout processing.",
      });
    }

    // If we reach here, it means no rating doc exists in ratings collection for this context,
    // and payout has not been processed. It's okay to proceed.
    // The session.rating field on the session document will be updated/set.

    // Create new Rating document
    const newRating = new Rating({
      expertId: ratedExpertId,
      raterId: raterMongoId,
      sessionId: session._id, // Save the session ID
      sessionModelName: session.constructor.modelName, // Save the model name (e.g., 'ExpertToExpertSession')
      sessionType: sessionType,
      rating: rating,
      comment: comment,
      raterType: raterType,
    });
    await newRating.save();
    console.log(
      `[Rating Submission] New rating document ${newRating._id} created in ratings collection.`
    );

    // Update session document
    session.rating = rating; // Keep numeric rating on session for payout calculation
    session.status = "Rating Submitted";

    let expertToPayId = ratedExpertId;

    if (session.price > 0 && expertToPayId) {
      const expertDoc = await Expert.findById(expertToPayId);

      if (expertDoc) {
        const averageRating = expertDoc.averageRating || 0; // Default to 0 if not set
        const expertSharePercentage = averageRating > 3 ? 0.7 : 0.5; // Use averageRating

        session.expertPayoutAmount = session.price * expertSharePercentage;
        session.platformFeeAmount = session.price * (1 - expertSharePercentage);

        // credit to new earning wallet
        expertDoc.wallets = expertDoc.wallets || { earning: { balance: 0, ledger: [] }, spending: { balance: 0, ledger: [] } };
        expertDoc.wallets.earning.balance += session.expertPayoutAmount;

        // create ledger transaction
        const creditTx = await Transaction.create({
          expertId: expertDoc._id,
          type: 'DEPOSIT',
          amount: session.expertPayoutAmount,
          status: 'COMPLETED',
          paymentMethod: 'WALLET',
          description: 'Expert-to-Expert session earnings',
          metadata: { origin: 'expert_to_expert_session', sessionId: session._id }
        });
        expertDoc.wallets.earning.ledger = expertDoc.wallets.earning.ledger || [];
        expertDoc.wallets.earning.ledger.push(creditTx._id);
        expertDoc.transactions = expertDoc.transactions || [];
        expertDoc.transactions.push(creditTx._id);
        await expertDoc.save();

        session.payoutProcessed = true;
        console.log(
          `[Rating Submission] Payout for expert ${expertToPayId} calculated using averageRating ${averageRating}. Payout: ${session.expertPayoutAmount}`
        );
      } else {
        console.error(
          `[Rating Submission] Expert with ID ${expertToPayId} not found for payout calculation.`
        );
        // Consider if payoutProcessed should be true and amount 0 if expert not found, or handle differently.
        // For now, if expert not found, payoutProcessed remains false for this paid session.
      }
    } else if (session.price === 0) {
      session.payoutProcessed = true;
      session.expertPayoutAmount = 0;
      session.platformFeeAmount = 0;
    }

    await session.save();
    console.log(
      `[Rating Submission] Session ${session._id} updated. Status: ${session.status}, Rating: ${session.rating}`
    );

    res.status(200).json({
      message: "Rating submitted and payout processed successfully.",
      sessionData: session, // Send back updated session
      ratingData: newRating, // Send back new rating document
    });
  } catch (error) {
    console.error("Error submitting rating and processing payout:", error);
    res.status(500).json({
      message: "An error occurred while submitting the rating.",
      error: error.message,
    });
  }
});

const getExpertPayoutHistory = asyncHandler(async (req, res) => {
  const expertId = req.user?._id;

  if (!expertId) {
    return res.status(401).json({ message: "Expert not authenticated." });
  }

  try {
    const expertToExpertSessions = await ExpertToExpertSession.find({
      consultingExpertID: expertId,
      payoutProcessed: true,
    })
      .populate("expertId", "firstName lastName") // The expert who booked this expert
      .sort({ updatedAt: -1 }); // Sort by when the payout was processed or session updated

    const userToExpertSessions = await UserToExpertSession.find({
      expertId: expertId,
      payoutProcessed: true,
    })
      .populate("userId", "firstName lastName") // The user who booked this expert
      .sort({ updatedAt: -1 });

    const formattedE2ESessions = expertToExpertSessions.map((session) => ({
      _id: session._id,
      sessionDate:
        session.slots &&
        session.slots.length > 0 &&
        session.slots[0].selectedDate
          ? session.slots[0].selectedDate
          : session.createdAt,
      rating: session.rating,
      sessionFee: session.price,
      expertEarnings: session.expertPayoutAmount,
      platformFeeAmount: session.platformFeeAmount,
      duration: session.duration,
      processedDateTime: session.updatedAt,
      status: session.status,
      sessionType: "expert-to-expert",
      participantName: session.expertId
        ? `${session.expertId.firstName} ${session.expertId.lastName}`
        : "N/A",
    }));

    const formattedU2ESessions = userToExpertSessions.map((session) => ({
      _id: session._id,
      sessionDate:
        session.slots &&
        session.slots.length > 0 &&
        session.slots[0].selectedDate
          ? session.slots[0].selectedDate
          : session.createdAt,
      rating: session.rating,
      sessionFee: session.price,
      expertEarnings: session.expertPayoutAmount,
      platformFeeAmount: session.platformFeeAmount,
      duration: session.duration,
      processedDateTime: session.updatedAt,
      status: session.status,
      sessionType: "user-to-expert",
      participantName: session.userId
        ? `${session.userId.firstName} ${session.userId.lastName}`
        : "N/A",
    }));

    const combinedHistory = [...formattedE2ESessions, ...formattedU2ESessions];
    combinedHistory.sort(
      (a, b) => new Date(b.processedDateTime) - new Date(a.processedDateTime)
    );

    res.status(200).json({ payouts: combinedHistory });
  } catch (error) {
    console.error("Error fetching expert payout history:", error);
    res.status(500).json({
      message: "An error occurred while fetching payout history.",
      error: error.message,
    });
  }
});

const markSessionAsCompleted = asyncHandler(async (req, res) => {
  const { sessionId } = req.params;
  const loggedInUserId = req.user?._id;

  if (!loggedInUserId) {
    return res.status(401).json({ message: "User not authenticated." });
  }

  try {
    let session = await ExpertToExpertSession.findById(sessionId);
    let sessionType = "expert-to-expert";

    if (!session) {
      session = await UserToExpertSession.findById(sessionId);
      sessionType = "user-to-expert";
    }

    if (!session) {
      return res.status(404).json({ message: "Session not found." });
    }

    // Authorization: Check if the logged-in user is part of the session
    let isParticipant = false;
    if (sessionType === "expert-to-expert") {
      if (
        session.expertId.toString() === loggedInUserId.toString() ||
        session.consultingExpertID.toString() === loggedInUserId.toString()
      ) {
        isParticipant = true;
      }
    } else {
      // user-to-expert
      if (
        session.userId.toString() === loggedInUserId.toString() ||
        session.expertId.toString() === loggedInUserId.toString()
      ) {
        isParticipant = true;
      }
    }

    if (!isParticipant) {
      return res
        .status(403)
        .json({
          message: "Forbidden: You are not a participant in this session.",
        });
    }

    if (session.status !== "confirmed") {
      return res.status(400).json({
        message: `Session status must be 'confirmed' to mark as completed. Current status: ${session.status}`,
      });
    }

    session.status = "completed";
    await session.save();

    res.status(200).json({
      message: "Session marked as completed successfully.",
      session,
    });
  } catch (error) {
    console.error("Error marking session as completed:", error);
    res.status(500).json({
      message: "An error occurred while marking the session as completed.",
      error: error.message,
    });
  }
});

// Add this new function after the existing functions
const sendSessionStatusEmail = async (session, status) => {
  try {
    const consultingExpert = await Expert.findById(
      session.consultingExpertID
    ).select("firstName lastName");
    const subject =
      status === "confirmed" ? "Session Confirmed" : "Session Rejected";
    const message =
      status === "confirmed"
        ? `Your session with expert ${consultingExpert.firstName} ${consultingExpert.lastName} has been confirmed.`
        : `Your session with expert ${consultingExpert.firstName} ${consultingExpert.lastName} has been rejected.`;

    await sendEmail({
      to: session.email,
      subject: subject,
      html: `<h1>${subject}</h1>
             <p>Hello ${session.firstName},</p>
             <p>${message}</p>
             <p>Session ID: ${session._id}</p>
             <p>Thank you for using our platform.</p>`,
    });
  } catch (error) {
    console.error(`Failed to send ${status} email notification:`, error);
  }
};

// Update the updateSessionStatus function to include email notification
const updateSessionStatus = asyncHandler(async (req, res) => {
  const { sessionId } = req.params;
  const { status } = req.body;
  
  const session = await ExpertToExpertSession.findById(sessionId)
    .populate('consultingExpertID', 'wallets transactions');
  
  if (!session) {
    throw new ApiError(404, "Session not found");
  }

  // Prevent status changes after completion
  if (session.status === 'completed') {
    throw new ApiError(400, "Completed sessions cannot be modified");
  }

  const originalStatus = session.status;
  session.status = status;

  // Critical: Only process payout when changing TO 'confirmed' state
  if (status === 'confirmed' && originalStatus !== 'confirmed' && !session.payoutProcessed) {
    const consultingExpert = session.consultingExpertID;
    
    // Initialize wallet structure if missing
    consultingExpert.wallets = consultingExpert.wallets || { 
      earning: { balance: 0, ledger: [] }, 
      spending: { balance: 0, ledger: [] } 
    };

    // Calculate actual payout (using sessionFee instead of expertPayoutAmount)
    const payoutAmount = session.sessionFee;
    
    // Update wallet balance
    consultingExpert.wallets.earning.balance += payoutAmount;

    // Create transaction record
    const creditTx = await Transaction.create({
      expertId: consultingExpert._id,
      type: 'DEPOSIT',
      amount: payoutAmount,
      status: 'COMPLETED',
      paymentMethod: 'WALLET',
      description: 'Expert session earnings (confirmed)',
      metadata: { 
        origin: 'expert_to_expert_session', 
        sessionId: session._id,
        bookedBy: session.bookedByExpertId // Track who booked the session
      }
    });

    // Update ledger
    consultingExpert.wallets.earning.ledger.push(creditTx._id);
    consultingExpert.transactions.push(creditTx._id);
    
    // Save changes atomically
    session.payoutProcessed = true;
    await consultingExpert.save();
  }

  await session.save();

  // Send email notification for confirmed or rejected status
  if (status === "confirmed" || status === "rejected") {
    await sendSessionStatusEmail(session, status);
  }

  res.status(200).json({
    success: true,
    message: `Session status updated to ${status}`,
    session,
  });
});

export {
  bookExpertToExpertSession,
  getMySessions,
  acceptSession,
  declineSession,
  getMyBookings,
  getExpertBookedSlots,
  submitRatingAndProcessPayout,
  getExpertPayoutHistory,
  markSessionAsCompleted,
  generateVideoSDKAuth,
  completeSession,
  completeSessionById,
  getSessionDetails,
  updateSessionStatus,
};
